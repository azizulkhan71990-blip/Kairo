package com.kairo.app

import android.content.Intent
import android.content.pm.PackageManager
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class KairoTileService : TileService() {

    override fun onStartListening() { refresh() }

    override fun onClick() {
        if (KairoService.running) {
            KairoService.stop(this)
        } else if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            KairoService.start(this)
        } else {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivityAndCollapse(i)
            return
        }
        qsTile?.state = if (KairoService.running) Tile.STATE_INACTIVE else Tile.STATE_ACTIVE
        qsTile?.updateTile()
    }

    private fun refresh() {
        qsTile?.state = if (KairoService.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        qsTile?.label = "Kairo"
        qsTile?.updateTile()
    }
}
