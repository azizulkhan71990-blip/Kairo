package com.kairo.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var sw: Switch
    private lateinit var overlayBtn: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0B1220"))
            setPadding(48, 48, 48, 48)
        }
        val title = TextView(this).apply {
            text = "KAIRO"; textSize = 40f; setTextColor(Color.parseColor("#4FC3F7")); gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 48, 0, 48)
        }
        sw = Switch(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); text = "চালু / বন্ধ  "; scaleX = 1.6f; scaleY = 1.6f
        }
        overlayBtn = Button(this).apply {
            text = "অ্যাপ খোলার অনুমতি দিন (একবার)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        val hint = TextView(this).apply {
            text = "\n\"কাইরো\" বলুন, তারপর যেমন: \"ইউটিউব খোলো\""
            textSize = 15f; setTextColor(Color.parseColor("#90A4AE")); gravity = Gravity.CENTER
        }
        root.addView(title); root.addView(status); root.addView(sw); root.addView(overlayBtn); root.addView(hint)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            KairoService.start(this)
        sw.postDelayed({ refresh() }, 400)
    }

    private fun refresh() {
        sw.setOnCheckedChangeListener(null)
        sw.isChecked = KairoService.running
        sw.setOnCheckedChangeListener { _, on ->
            if (on) {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
                else KairoService.start(this)
            } else KairoService.stop(this)
            sw.postDelayed({ refresh() }, 500)
        }
        status.text = if (KairoService.running) "Kairo চালু আছে" else "Kairo বন্ধ"
        overlayBtn.visibility = if (Settings.canDrawOverlays(this)) android.view.View.GONE else android.view.View.VISIBLE
    }
}
