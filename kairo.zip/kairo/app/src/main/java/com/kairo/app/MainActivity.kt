package com.kairo.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var toggle: Button
    private lateinit var overlayBtn: Button
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0B1220"))
            setPadding(48, 48, 48, 48)
        }
        val title = TextView(this).apply {
            text = "KAIRO"; textSize = 40f; setTextColor(Color.parseColor("#4FC3F7")); gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 32, 0, 32)
        }
        toggle = Button(this).apply {
            textSize = 20f
            setOnClickListener {
                if (KairoService.running) KairoService.stop(this@MainActivity)
                else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
                else KairoService.start(this@MainActivity)
                h.postDelayed({ refresh() }, 500)
            }
        }
        heard = TextView(this).apply {
            textSize = 16f; setTextColor(Color.parseColor("#FFD54F")); gravity = Gravity.CENTER; setPadding(0, 32, 0, 32)
        }
        overlayBtn = Button(this).apply {
            text = "অ্যাপ খোলার অনুমতি দিন (একবার)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        val hint = TextView(this).apply {
            text = "\n\"কাইরো\" বলুন, তারপর যেমন: \"ইউটিউব খোলো\""
            textSize = 15f; setTextColor(Color.parseColor("#90A4AE")); gravity = Gravity.CENTER
        }
        root.addView(title); root.addView(status); root.addView(toggle); root.addView(heard)
        root.addView(overlayBtn); root.addView(hint)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            KairoService.start(this)
        h.postDelayed({ refresh() }, 500)
    }

    private fun refresh() {
        val on = KairoService.running
        status.text = if (on) "Kairo চালু আছে" else "Kairo বন্ধ"
        toggle.text = if (on) "বন্ধ করুন" else "চালু করুন"
        heard.text = if (on) KairoService.lastInfo else ""
        overlayBtn.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
    }
}
