package com.kairo.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale

class KairoService : Service(), RecognitionListener, TextToSpeech.OnInitListener {

    companion object {
        var running = false
        const val ACTION_STOP = "kairo.stop"
        fun start(c: Context) {
            val i = Intent(c, KairoService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }
        fun stop(c: Context) { c.stopService(Intent(c, KairoService::class.java)) }

        val WAKE = listOf("কাইরো", "কায়রো", "কাইরও", "কেইরো", "ক্যায়রো", "কাইরো", "kairo", "cairo", "kyro", "kayro")
        val OPEN = listOf("খোলো", "খুলো", "খুল", "খোল", "চালু করো", "চালাও", "ওপেন", "open", "start")
        val ALIAS = mapOf(
            "ইউটিউব" to "youtube", "ইউটিউবে" to "youtube", "ফেসবুক" to "facebook",
            "হোয়াটসঅ্যাপ" to "whatsapp", "হোয়াটসাপ" to "whatsapp", "ক্রোম" to "chrome",
            "ক্যামেরা" to "camera", "গ্যালারি" to "gallery", "সেটিংস" to "settings",
            "বিকাশ" to "bkash", "নগদ" to "nagad", "মেসেজ" to "messages", "ম্যাপ" to "maps",
            "জিমেইল" to "gmail", "ক্যালকুলেটর" to "calculator", "ঘড়ি" to "clock",
            "ফোন" to "phone", "কন্টাক্ট" to "contacts", "মেসেঞ্জার" to "messenger",
            "ইমো" to "imo", "টেলিগ্রাম" to "telegram", "ইনস্টাগ্রাম" to "instagram"
        )
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var awaiting = false
    private var speaking = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (running) return START_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("kairo", "Kairo", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0,
            Intent(this, KairoService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "kairo")
            .setContentTitle("Kairo চালু")
            .setContentText("\"কাইরো\" বলুন...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "বন্ধ করুন", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        running = true
        tts = TextToSpeech(this, this)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("এই ফোনে স্পিচ রিকগনিশন নেই (Google অ্যাপ লাগবে)")
        } else {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
            main.postDelayed({ listen() }, 800)
        }
        return START_STICKY
    }

    // ---------- শোনা ----------
    private fun listen() {
        if (!running || speaking) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { recognizer?.startListening(i) } catch (e: Exception) { main.postDelayed({ listen() }, 1500) }
    }

    override fun onResults(r: Bundle?) {
        val list = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
        if (list.isNotEmpty()) handle(list)
        main.postDelayed({ listen() }, 250)
    }

    override fun onError(error: Int) {
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { toast("মাইক্রোফোনের অনুমতি দিন"); stopSelf(); return }
        if (awaiting && (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) awaiting = false
        val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200L else 400L
        main.postDelayed({ listen() }, delay)
    }

    // ---------- কমান্ড ----------
    private fun handle(heard: List<String>) {
        val text = heard.joinToString(" | ").lowercase()
        if (awaiting) {
            awaiting = false
            execute(heard.first().lowercase())
            return
        }
        val hit = heard.map { it.lowercase() }.firstOrNull { h -> WAKE.any { h.contains(it) } } ?: return
        var rest = hit
        WAKE.forEach { rest = rest.replace(it, " ") }
        rest = rest.trim()
        if (rest.isEmpty()) { awaiting = true; say("বলুন") } else execute(rest)
    }

    private fun execute(cmd: String) {
        if (OPEN.any { cmd.contains(it) }) {
            var name = cmd
            OPEN.forEach { name = name.replace(it, " ") }
            name = name.replace("অ্যাপ", " ").replace("টা", " ").trim()
            openApp(name)
        } else {
            say("এই কমান্ড এখনো শিখিনি")
        }
    }

    private fun openApp(spoken: String) {
        if (spoken.isEmpty()) { say("কোন অ্যাপ?"); awaiting = true; return }
        val key = ALIAS.entries.firstOrNull { spoken.contains(it.key) }?.value ?: spoken
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
        val m = apps.firstOrNull {
            val l = it.loadLabel(pm).toString().lowercase()
            l == key || l.contains(key) || key.contains(l)
        }
        if (m == null) { say("অ্যাপ পাইনি"); toast("পাইনি: $spoken"); return }
        val launch = pm.getLaunchIntentForPackage(m.activityInfo.packageName)
        if (launch == null) { say("অ্যাপ খোলা যায়নি"); return }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(launch)
            toast(m.loadLabel(pm).toString() + " খুলছি")
        } catch (e: Exception) { say("অনুমতি লাগবে, অ্যাপে গিয়ে দিন") }
    }

    // ---------- কথা বলা ----------
    override fun onInit(status: Int) {
        val t = tts ?: return
        var r = t.setLanguage(Locale("bn", "BD"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) r = t.setLanguage(Locale.ENGLISH)
        ttsReady = status == TextToSpeech.SUCCESS
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { main.post { speaking = false; listen() } }
            override fun onDone(id: String?) { main.post { speaking = false; listen() } }
        })
    }

    private fun say(s: String) {
        toast(s)
        if (!ttsReady) return
        speaking = true
        try { recognizer?.cancel() } catch (_: Exception) {}
        tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "u1")
    }

    private fun toast(s: String) { main.post { Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show() } }

    override fun onBeginningOfSpeech() {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(t: Int, p: Bundle?) {}
    override fun onPartialResults(p: Bundle?) {}
    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onRmsChanged(r: Float) {}

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
