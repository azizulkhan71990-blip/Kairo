plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.kairo.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.kairo.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "0.3"
    }
    signingConfigs {
        create("kairo") {
            storeFile = file("kairo.keystore")
            storePassword = "kairo123"
            keyAlias = "kairo"
            keyPassword = "kairo123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("kairo") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
